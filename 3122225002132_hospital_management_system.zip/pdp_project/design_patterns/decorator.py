
# design_patterns/decorator.py
from datetime import datetime

def add_patient_log_decorator(append_func):
    def wrapper(*args, **kwargs):
        patient = kwargs.get('patient')
        if patient:
            # Extract the 'patient' keyword argument and pass it to list.append()
            append_func(patient)

            # Log additional information or perform other actions if needed

    return wrapper
