# design_patterns/command.py
class PatientCommand:
    def __init__(self, execute_func, undo_func):
        self.execute_func = execute_func
        self.undo_func = undo_func

    def execute(self, **kwargs):
        self.execute_func(**kwargs)

    def undo(self, **kwargs):
        self.undo_func(**kwargs)
