# design_patterns/observer.py
class PatientObserver:
    def update(self, patient):
        print(f"Patient {patient['name']} details updated.")
