# design_patterns/adapter.py
class PatientAdapter:
    def __init__(self, patient):
        self.patient = patient

    def get_patient_details(self):
        return {
            "patient_id": self.patient["id"],
            "name": self.patient["name"],
            "age": self.patient["age"],
            "address": self.patient["address"],
            "date_of_join": self.patient["date_of_join"],
            "type_of_room": self.patient["type_of_room"],
            "date_of_discharge": self.patient["date_of_discharge"],
            "days_admitted": self.patient["days_admitted"],
            "room_bill": self.patient["room_bill"]
        }
