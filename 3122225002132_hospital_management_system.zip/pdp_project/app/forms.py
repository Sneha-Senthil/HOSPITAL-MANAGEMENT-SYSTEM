# app/forms.py
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, IntegerField,SelectField
from wtforms.validators import DataRequired

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])

class PatientForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    age = IntegerField('Age', validators=[DataRequired()])
    address = StringField('Address', validators=[DataRequired()])
    date_of_appointment = StringField('Date of Appointment', validators=[DataRequired()])
    doctor_appointed = StringField('Doctor Appointed', validators=[DataRequired()])
    medical_symptom = StringField('Medical Symptom', validators=[DataRequired()])

class MedicineForm(FlaskForm):
    medicine_name = SelectField('Medicine Name', validators=[DataRequired()], choices=[('paracetamol', 'Paracetamol'), ('ibuprofen', 'Ibuprofen'), ('aspirin', 'Aspirin')])
    quantity = IntegerField('Quantity', validators=[DataRequired()])
