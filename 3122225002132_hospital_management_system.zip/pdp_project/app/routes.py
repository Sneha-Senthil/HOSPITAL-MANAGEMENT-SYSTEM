# app/routes.py
import json
from flask import render_template, request, redirect, url_for,  jsonify
from app import app
from app.forms import LoginForm, PatientForm, MedicineForm
from design_patterns.iterator import PatientIterator
from design_patterns.decorator import add_patient_log_decorator
from design_patterns.command import PatientCommand
from design_patterns.adapter import PatientAdapter
from design_patterns.observer import PatientObserver

users = [
    {"username": "admin", "password": "password123"},
]

with open('patients.json', 'r') as file:
    patients = json.load(file)

# Create instances for design patterns
patient_iterator = PatientIterator(patients)
add_patient_log = add_patient_log_decorator(patients.append)
patient_observer = PatientObserver()
add_patient_command = PatientCommand(execute_func=add_patient_log, undo_func=patients.pop)


# Routes
def save_patient_data():
    with open('patients.json', 'w') as file:
        json.dump(patients, file,indent=2)

@app.route('/undo_last_patient', methods=['GET'])
def undo_last_patient():
    add_patient_command.undo()
    save_patient_data()
    return redirect(url_for('home'))

@app.route('/', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    error = None  # Variable to store error messages

    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data

        # Check if the provided username and password match any user
        user = next((user for user in users if user["username"] == username and user["password"] == password), None)

        if user:
            # Authentication successful, redirect to the home page
            return redirect(url_for('home'))
        else:
            # Authentication failed, set an error message
            error = "Invalid username or password"

    return render_template('login.html', form=form, error=error)

@app.route('/home', methods=['GET', 'POST'])
def home():
    return render_template('home.html', patients=patients)


@app.route('/patient/<int:patient_id>', methods=['GET'])
def patient_details(patient_id):
    patient = next((p for p in patients if p.get("id") == patient_id), None)
    if patient:
        # Use the adapter pattern to get patient details
        patient_adapter = PatientAdapter(patient)
        patient_details = patient_adapter.get_patient_details()
        return render_template('patient_details.html', patient=patient_details)
    return redirect(url_for('home'))

@app.route('/add_patient', methods=['GET', 'POST'])
def add_patient():
    form = PatientForm()
    if form.validate_on_submit():
        patient = {
            "id": len(patients) + 1,
            "name": form.name.data,
            "age": form.age.data,
            "address": form.address.data,
            "date_of_appointment": form.date_of_appointment.data,
            "Doctor_appointed": form.doctor_appointed.data,
            "Medical_symptom": form.medical_symptom.data,
            "medicines":[]
        }

        # Use the command pattern to add patient
        add_patient_command = PatientCommand(execute_func=add_patient_log, undo_func=patients.pop)
        add_patient_command.execute(patient=patient)

        # Notify the observer (for demonstration purposes)
        patient_observer.update(patient)
        save_patient_data()
        return redirect(url_for('home'))

    return render_template('add_patient.html', form=form)



@app.route('/issue_medicine/<int:patient_id>', methods=['GET', 'POST'])
def issue_medicine(patient_id):
    patient = next((p for p in patients if p.get("id") == patient_id), None)
    form = MedicineForm()

    if patient and form.validate_on_submit():
        medicine_data = {
            "medicine_name": form.medicine_name.data,
            "quantity": form.quantity.data,
            # Add other medicine details if needed
        }

        # Append the medicine data to the patient's medicines list
        patient["medicines"].append(medicine_data)

        # Save the updated patients data to patients.json
        save_patient_data()

        return redirect(url_for('generate_bill', patient_id=patient.get("id")))

    return render_template('issue_medicine.html', patient=patient, form=form)


@app.route('/generate_bill/<int:patient_id>', methods=['GET'])
def generate_bill(patient_id):
    patient = next((p for p in patients if p["id"] == patient_id), None)

    if patient:
        # Calculate medicine fee, consulting fee, and total fee
        medicine_fee = calculate_medicine_fee(patient.get("medicines", []))
        consulting_fee = get_consulting_fee()
        total_fee = medicine_fee + consulting_fee

        return render_template('bill_details.html', patient=patient, medicine_fee=medicine_fee, consulting_fee=consulting_fee, total_fee=total_fee)

    return render_template('error_page.html', error="Patient not found")


def calculate_medicine_fee(medicines):
    # Implement your logic to calculate medicine fee based on predefined medicine prices
    # You can use a predefined dictionary of medicine prices
    medicine_prices = {"paracetamol": 10, "aspirin": 20, "ibuprofen": 30}

    total_fee = 0  # Initialize total_fee to 0

    for medicine in medicines:
        # Check if the 'medicines' key exists in the current patient data
        if 'medicine_name' in medicine and 'quantity' in medicine:
            total_fee += medicine_prices.get(medicine["medicine_name"], 0) * medicine["quantity"]

    return total_fee


def get_consulting_fee():
    # Implement your logic to get the consulting fee
    # You can define a fixed consulting fee or use some other logic
    return 150

